/** Automatically generated file. DO NOT MODIFY */
package com.example.phplearningapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}